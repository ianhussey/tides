maximumSD <-
function(M,MIN,MAX,n){
  maximumSD<-sqrt(maximumVAR(M,MIN,MAX,n))
}
