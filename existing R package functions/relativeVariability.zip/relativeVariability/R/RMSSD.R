RMSSD <-
function(X)  {
    v <- sqrt(MSSD(X)) 
  RMSSD<-v
}
