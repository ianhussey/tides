IQR <-
function(X)  {
  # the interquartile range of X 
  v <- IPR(X,0.25,0.75) 
  IQR<-v
}
