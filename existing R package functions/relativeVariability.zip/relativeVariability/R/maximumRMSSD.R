maximumRMSSD <-
function(MEAN,MIN,MAX,nParts)  {
  maximumRMSSD<-sqrt(maximumMSSD(MEAN,MIN,MAX,nParts) )
}
